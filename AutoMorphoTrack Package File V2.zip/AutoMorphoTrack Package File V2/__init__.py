from .core import run_full_pipeline
