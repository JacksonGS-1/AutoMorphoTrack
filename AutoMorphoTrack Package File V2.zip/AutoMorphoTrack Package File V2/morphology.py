
def classify_mitochondria(properties):
    classified = []
    for prop in properties:
        if prop.area >= 0.2 and prop.eccentricity >= 0.9:
            classified.append('elongated')
        elif prop.area >= 0.02:
            classified.append('punctate')
    return classified
