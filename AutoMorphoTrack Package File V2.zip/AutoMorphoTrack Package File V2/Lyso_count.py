import numpy as np
import cv2
from skimage.measure import label, regionprops
import matplotlib.pyplot as plt


def count_lysosomes(binary_masks, min_area=1):
    """
    Counts lysosomes in each frame based on binary masks.

    Parameters:
        binary_masks (np.ndarray): 3D array of binary masks (frames x height x width).
        min_area (float): Minimum area (in pixels) to count an object as a lysosome.

    Returns:
        counts_per_frame (list): Lysosome count per frame.
        labeled_masks (list): List of label images per frame.
    """
    counts_per_frame = []
    labeled_masks = []

    for frame in binary_masks:
        labeled = label(frame)
        props = regionprops(labeled)
        valid_regions = [p for p in props if p.area >= min_area]
        count = len(valid_regions)
        counts_per_frame.append(count)
        labeled_frame = np.zeros_like(frame)
        for i, region in enumerate(valid_regions, start=1):
            labeled_frame[labeled == region.label] = i
        labeled_masks.append(labeled_frame)

    return counts_per_frame, labeled_masks


def visualize_lysosome_counts(image_stack, labeled_masks, counts, save_path=None):
    """
    Overlay lysosome counts and labels on the first frame of the stack.

    Parameters:
        image_stack (np.ndarray): Original grayscale or RGB stack.
        labeled_masks (list): List of labeled masks (one per frame).
        counts (list): List of counts per frame.
        save_path (str): Optional path to save the visualization.
    """
    frame = image_stack[0]
    labeled = labeled_masks[0]
    plt.figure(figsize=(8, 8))
    plt.imshow(frame, cmap='gray')
    props = regionprops(labeled)

    for region in props:
        y, x = region.centroid
        plt.text(x, y, f"{region.label}", color='lime', fontsize=10, ha='center', va='center')

    plt.title(f"Lysosomal Count (Frame 0): {counts[0]}", fontsize=14)
    plt.axis('off')

    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()
