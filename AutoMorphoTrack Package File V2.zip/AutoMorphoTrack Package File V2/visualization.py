
import matplotlib.pyplot as plt

def plot_organelles(image, mask):
    plt.imshow(image, cmap='gray')
    plt.contour(mask, colors='red')
    plt.show()
