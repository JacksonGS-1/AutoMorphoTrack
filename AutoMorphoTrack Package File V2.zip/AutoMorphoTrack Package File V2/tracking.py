
import numpy as np

def calculate_displacement(tracks):
    displacement = [np.linalg.norm(track[-1] - track[0]) for track in tracks]
    return displacement
