
from .detection import detect_organelles
from .tracking import calculate_displacement
from .morphology import classify_mitochondria
from .visualization import plot_organelles

def run_full_pipeline(image_stack):
    for frame in image_stack:
        mask = detect_organelles(frame)
        plot_organelles(frame, mask)
